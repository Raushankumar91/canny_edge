

import matplotlib.pyplot as plt;
import matplotlib.image as mpimg
import cv2;
import numpy as np;
import time
import math
import os;
import sys;
def pr(a):
    for i in range(0,15,1):
        for j in range(0,15,1):
            print(a[i][j]," ",end='');
        print ();
    print();
def gauss(gimg,g,height,width,u):
    for i in range(2,height-2,1):
        for j in range(2,width-2,1):
           p=0;
           for w in range(0,5,1):
               for x in range(0,5,1):
                   p=p+g[w][x]*gimg[i+w-2][j+x-2];
           p=int(round(float(p/273)));
           u[i][j]=p;
    for i in range(2,height-2,1):
        for j in range(2,width-2,1):
            gimg[i][j]=int(u[i][j]);
def gradient(gimg,height,width,u,m,q):
    gb=[[1,2,1],[0,0,0],[-1,-2,-1]];
    ga = [[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]];
    for i in range(1,height-1,1):
        for j in range(1,width-1,1):
           p1=0;
           p2=0;
           for w in range(0,3,1):
               for x in range(0,3,1):
                   p1=p1+ga[w][x]*gimg[i+w-1][j+x-1];
                   p2 = p2 + gb[w][x] * gimg[i + w - 1][j + x - 1];
           p8=int(pow(p1,2))+int(pow(p2,2));
           p10=int(math.sqrt(p8));
           try:
              p6=float(np.arctan2(p2,p1));
           except(e):
               pass;
           m[i][j]=p10;
           q[i][j]=p6;
if __name__=="__main__":
    img = cv2.imread(r"einstein.jpg");
    gimg=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY);
    cv2.imshow('gray',gimg);
    height,width=gimg.shape;
    g = [[1, 4, 7, 4, 1], [4, 16, 26, 16, 4], [7, 26, 41, 26, 7], [4, 16, 26, 16, 4], [1, 4, 7, 4, 1]];
    u = np.empty([height, width], dtype='float');
    gauss(gimg, g, height, width, u);
    m = np.empty([height, width], dtype='int')
    q = np.empty([height, width], dtype='float')
    cv2.imshow('gauss',gimg);
    gradient(gimg, height, width, u, m, q);
    ram = [];
    for i in range(0, height, 1):
        for j in range(0, width, 1):
            gimg[i][j] = m[i][j];
    cv2.imshow('gradient',gimg);
    ram = [];
    for i in range(1, height - 1, 1):
        for j in range(1, width - 1, 1):
            if (q[i][j] <= (math.pi / 8) or q[i][j] > (0.875 * math.pi)):
                if (gimg[i][j] >= gimg[i][j - 1] and gimg[i][j] >= gimg[i][j + 1]):
                    pass;
                else:
                    gimg[i][j] = 0;
            elif (q[i][j] <= (math.pi / 4) or q[i][j] > (0.75 * math.pi)):
                if (gimg[i][j] >= gimg[i - 1][j + 1] and gimg[i][j] >= gimg[i + 1][j - 1]):
                    pass;
                else:
                    gimg[i][j] = 0
            elif (q[i][j] <= (0.375 * math.pi) or q[i][j] > (0.625 * math.pi)):
                if (gimg[i][j] >= gimg[i - 1][j] and gimg[i][j] >= gimg[i + 1][j]):
                    pass;
                else:
                    gimg[i][j] = 0
            elif (q[i][j] <= (0.375 * math.pi) or q[i][j] > (0.625 * math.pi)):
                if (gimg[i][j] >= gimg[i - 1][j - 1] and gimg[i][j] >= gimg[i + 1][j + 1]):
                    pass;
                else:
                    gimg[i][j] = 0
    pr(gimg);
    cv2.imshow('max-supp',gimg);
    max1 = gimg.max();
    '''ngimg = np.empty([height, width], dtype='int');
    for i in range(0, height, 1):
        for j in range(0, width, 1):
            ngimg[i][j] = gimg[i][j];'''
    ht = 0.2 * max1;
    lt = 0.1 * ht;
    print(ht, lt);
    ram = [];
    ram1 = [];
    pr(gimg);
    for i in range(1, height - 1, 1):
        for j in range(1, width - 1, 1):
            if (gimg[i][j] >= ht):
                gimg[i][j] = 255;
            elif (gimg[i][j] <= lt):
                gimg[i][j] = 0;
            else:
                if (gimg[i][j + 1] >= ht or gimg[i][j + 1] >= ht or gimg[i + 1][j] >= ht or gimg[i - 1][j] >= ht or
                        gimg[i][j - 1] >= ht or gimg[i + 1][j - 1] >= ht or gimg[i - 1][j + 1] >= ht or gimg[i + 1][
                            j + 1] >= ht):
                    val = [i, j];
                    ram.append(val);
                else:
                    gimg[i][j] = 0;
                    ram1.append(val);

    n60 = len(ram);
    print(n60);
    for i in range(0, n60, 1):
        gimg[ram[i][0]][ram[i][1]] = 255;
    pr(gimg);
    cv2.imshow('hys',gimg);
    cv2.waitKey(0);
    cv2.destroyAllWindows();


